from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('song/', views.song_list, name='song_list'),
    path('song/<int:song_id>/', views.song_index, name='song'),
    path('song/new/', views.song_new, name='song_new'),
    path('artist/', views.artist_list, name='artist_list'),
    path('artist/new/', views.artist_new, name='artist_new'),
    path('artist/<int:artist_id>/', views.artist_index, name='artist'),
]
