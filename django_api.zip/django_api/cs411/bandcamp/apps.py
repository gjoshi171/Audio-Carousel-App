from django.apps import AppConfig


class BandcampConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bandcamp'
