from django.db import models
from django.forms import ModelForm


# Create your models here.

class Artist(models.Model):
    name = models.CharField(max_length=200)
    oauth = models.CharField(max_length=200)
    def __str__(self):
        return self.name

class ArtistForm(ModelForm):
    class Meta:
        model = Artist
        fields = ['oauth', 'name']

class Song(models.Model):
    title = models.CharField(max_length=100)
    lyrics = models.TextField(blank=True,null=True)
    artist = models.ForeignKey(Artist, related_name='songs', on_delete=models.CASCADE)
    duration = models.DurationField(blank=True,null=True)

    image = models.FileField(upload_to='cs411/images/', blank=True,null=True)
    audio = models.FileField(upload_to='cs411/audio/', blank=True,null=True)

    def __str__(self):
        return ' - '.join([str(self.artist), self.title])
    

class SongForm(ModelForm):
    class Meta:
        model = Song
        fields = ['title', 'lyrics', 'duration', 'artist', 'image', 'audio']

