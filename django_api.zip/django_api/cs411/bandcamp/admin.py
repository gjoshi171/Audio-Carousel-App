from django.contrib import admin

from .models import *

admin.site.register(Artist)
admin.site.register(Song)

# Register your models here.
