from django.shortcuts import render
from django.http import HttpResponse
from django.http import JsonResponse

from django.views.decorators.csrf import csrf_exempt

from .models import *

def index(request):
    j = {
            "live": {
                "req_song_list": "request songlist at /api/song/",
                "req_song_id": "request song by id at /api/song/<id>",
                "req_artist_list": "request artist list at /api/artist/",
                "req_artist_id": "request artist by id at /api/artist/<id>",
                "req_song_search": "request songs by search params at /api/song/?title=Mercy&artist=marv?lyrics=hate",
                "post_artist": "create new artist at /api/artist/new/ with post values of name=name and oauth=oauthid",
                "post_song": "create new song at /api/song/new/ with post values title=title artist=artist_id lyrics=lyrics duration=duration image=imagefile audio=audiofile"
            },
            "work_in_progress": {
            }
    }

    return JsonResponse(j, safe=False) 

@csrf_exempt #horible security....
def artist_new(request):
    if request.POST:
        form = ArtistForm(request.POST)
        if form.is_valid():
            artist = form.save()
            d = {'status':'success','artist_id':artist.id}
            return JsonResponse(d, safe=False)
        else:
            d = {'status':'failure','data':'form data invalid'}
            return JsonResponse(d, safe=False)

    d = {'status':'failure', 'data':'should be POST request'}
    return JsonResponse(d, safe=False)


def artist_list(request):
    artists = Artist.objects.order_by('-id')[:20].values()
    artist_list = list(artists)

    return JsonResponse(artist_list, safe=False)

def artist_index(request, artist_id):
    artist = Song.objects.filter(pk=artist_id).values()
    artist = list(artist)

    return JsonResponse(artist, safe=False)


def song_list(request):
    qs = Song.objects.all()
    qs_song = Song.objects.none() 
    qs_artist = Song.objects.none() 
    qs_lyrics = Song.objects.none() 

    title = request.GET.get('title')
    if title is not None:
        qs_song =  qs.filter(title__icontains=title)

    artist = request.GET.get('artist')
    if artist is not None:
        artists =  Artist.objects.filter(name__icontains=artist).first()
        qs_artist = artists.songs.all()

    lyrics = request.GET.get('lyrics')
    if lyrics is not None:
        qs_lyrics =  qs.filter(lyrics__icontains=lyrics)

    if title or artist or lyrics: 
        qs = qs_song.union(qs_artist, qs_lyrics)  # distinct() already included in union

    songs = qs.order_by('-id')[:20].values('id','title','lyrics','artist_id','artist__name','image','audio','duration')
    song_list = list(songs)
    return JsonResponse({"status":"success","data":{"songs": song_list}}, safe=False)


def song_index(request, song_id):
    song = Song.objects.filter(pk=song_id).values()
    song = list(song)

    return JsonResponse({"status":"success","data":{"song": song}}, safe=False)


@csrf_exempt #horible security....
def song_new(request):
    if request.POST:
        form = SongForm(request.POST, request.FILES)
        if form.is_valid():
            song = form.save()
            d = {'status':'success',"data":{"song_id":song.id}}
            return JsonResponse(d, safe=False)
        else:
            d = {'status':'failure','data':'form data invalid'}
            return JsonResponse(d, safe=False)

    d = {'status':'failure', 'data':'should be POST request'}
    return JsonResponse(d, safe=False)



